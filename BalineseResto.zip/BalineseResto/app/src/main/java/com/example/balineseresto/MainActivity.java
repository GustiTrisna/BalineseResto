package com.example.balineseresto;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "MainActivity";

    //vars
    private ArrayList<String> mNames = new ArrayList<>();
    private ArrayList<String> mImageUrls = new ArrayList<>();

    //TextView image_jumlah;
    //int jumlah;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.d(TAG, "onCreate: started.");

        //image_jumlah = findViewById(R.id.image_jumlah);

        initImageBitmaps();
    }

    private void initImageBitmaps() {
        Log.d(TAG, "initImageBitmaps: preparing bitmaps.");

        mImageUrls.add("https://upload.wikimedia.org/wikipedia/commons/thumb/1/11/Lawar_babi_guling.jpg/800px-Lawar_babi_guling.jpg");
        mNames.add("Nasi Babi Guling");
        mImageUrls.add("https://blue.kumparan.com/kumpar/image/upload/fl_progressive,fl_lossy,c_fill,q_auto:best,w_640/v1528461052/0806_Kuliner_Buleleng_Siobak_ipbscy.jpg");
        mNames.add("Siobak");
        mImageUrls.add("https://scontent-atl3-1.cdninstagram.com/vp/65bd6d7aa655721f4c13c0b3f1d3a6de/5D6FC1BD/t51.2885-15/e35/56226300_408063576415872_463379959060379871_n.jpg?_nc_ht=scontent-atl3-1.cdninstagram.com");
        mNames.add("Nasi Lawar");
        mImageUrls.add("https://1.bp.blogspot.com/-BdCv5AhV_Cw/WwgtNzkjGFI/AAAAAAAAAx8/mdY-4GnzG5YCI5noiQjOTE-Mc-AfQ8fBQCLcBGAs/s1600/warungsateceleng_menlala_32392848_1717157005028053_3842895990658957312_n.jpg");
        mNames.add("Sate Babi");
        mImageUrls.add("https://cfcdn2.azsg.opensnap.com/azsg/snapphoto/photo/LD/GW5D/3C4MAGC559A91FC3251612lv.jpg");
        mNames.add("Nasi Betutu");

        initRecycleView();
    }

    private void initRecycleView() {
        Log.d(TAG, "initRecycleView: init recycleview.");

        RecyclerView recyclerView = findViewById(R.id.recycler_view);
        RecyclerViewAdapter adapter = new RecyclerViewAdapter(this, mNames, mImageUrls);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return super.onCreateOptionsMenu(menu);
    }
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.action_list:
                break;

            case R.id.action_grid:
                break;

            case R.id.action_cardview:
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    //public void tambah(View view){
    //    jumlah = jumlah +1;
    //    image_jumlah.setText("" +jumlah);
    //}
    //public void kurang(View view){
    //jumlah = jumlah -1;
    //    image_jumlah.setText("" +jumlah);
    //}
}
